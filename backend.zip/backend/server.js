const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5001;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Connect MongoDB
mongoose.connect(process.env.MONGO_URI, { 
  useNewUrlParser: true, 
  useUnifiedTopology: true 
})
.then(() => console.log("MongoDB connected"))
.catch(err => console.log(err));

// Schemas
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  password: String,
  role: { type: String, default: "student" } // student or warden
});

const complaintSchema = new mongoose.Schema({
  title: String,
  description: String,
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" }
});

const User = mongoose.model("User", userSchema);
const Complaint = mongoose.model("Complaint", complaintSchema);

// Auth Middleware
const auth = async (req, res, next) => {
  const token = req.header("Authorization")?.replace("Bearer ", "");
  if (!token) return res.status(401).json({ message: "No token, auth denied" });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select("-password");
    next();
  } catch (err) {
    res.status(401).json({ message: "Token not valid" });
  }
};

// Routes

// Register
app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: "User already exists" });

    const newUser = new User({ name, email, password, role });
    await newUser.save();
    res.json({ message: "Registration successful" });
  } catch (err) {
    res.status(500).json({ message: "Error registering user" });
  }
});

// Login
app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email, password });
    if (!user) return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1d" });
    res.json({ token, role: user.role, name: user.name });
  } catch (err) {
    res.status(500).json({ message: "Login error" });
  }
});

// Create Complaint
app.post("/api/complaints", auth, async (req, res) => {
  try {
    const { title, description } = req.body;
    const complaint = new Complaint({ title, description, user: req.user._id });
    await complaint.save();
    res.json({ message: "Complaint submitted" });
  } catch (err) {
    res.status(500).json({ message: "Error submitting complaint" });
  }
});

// Get Complaints
app.get("/api/complaints", auth, async (req, res) => {
  try {
    if (req.user.role === "warden") {
      const complaints = await Complaint.find().populate("user", "name email");
      return res.json(complaints);
    } else {
      const complaints = await Complaint.find({ user: req.user._id });
      return res.json(complaints);
    }
  } catch (err) {
    res.status(500).json({ message: "Error fetching complaints" });
  }
});

// Start Server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
