const express = require('express');
const router = express.Router();
const Complaint = require('../models/Complaint');
const auth = require('../middleware/auth');

// Submit complaint
router.post('/', auth, async (req,res) => {
  const { title, description } = req.body;
  const complaint = new Complaint({ title, description, user: req.user._id });
  await complaint.save();
  res.json({ message: "Complaint submitted" });
});

// Get complaints
router.get('/', auth, async (req,res) => {
  if(req.user.role === 'warden') {
    const complaints = await Complaint.find().populate('user','name email');
    res.json(complaints);
  } else {
    const complaints = await Complaint.find({ user: req.user._id });
    res.json(complaints);
  }
});

module.exports = router;
